package Model;

public class Principal extends javax.swing.JFrame {

    public Principal() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblFiguraPrincipal = new javax.swing.JLabel();
        MenuPrincipal = new javax.swing.JMenuBar();
        MenuCadastro = new javax.swing.JMenu();
        MenuItemFornecedor = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        MenuCliente = new javax.swing.JMenu();
        MenuItemPF = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        MenuItemPJ = new javax.swing.JMenuItem();
        jSeparator3 = new javax.swing.JPopupMenu.Separator();
        MenuBD = new javax.swing.JMenu();
        MenuItemConectar = new javax.swing.JMenuItem();
        jSeparator4 = new javax.swing.JPopupMenu.Separator();
        MenuItemDesconectar = new javax.swing.JMenuItem();
        jSeparator5 = new javax.swing.JPopupMenu.Separator();
        MenuItemProduto = new javax.swing.JMenuItem();
        jSeparator6 = new javax.swing.JPopupMenu.Separator();
        MenuItemExit = new javax.swing.JMenuItem();
        MenuVendas = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        MenuNotaFiscal = new javax.swing.JMenu();
        jMenuItem2 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Projeto Ribeirão Pires - Controle de Estoque");
        setExtendedState(MAXIMIZED_BOTH);
        setName("Principal"); // NOI18N

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 0, 51), 1, true));

        lblFiguraPrincipal.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFiguraPrincipal.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/ribeirao pires.png"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblFiguraPrincipal, javax.swing.GroupLayout.DEFAULT_SIZE, 887, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblFiguraPrincipal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        MenuCadastro.setForeground(new java.awt.Color(0, 0, 51));
        MenuCadastro.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/cadastro.png"))); // NOI18N
        MenuCadastro.setMnemonic('C');
        MenuCadastro.setText("Cadastro");
        MenuCadastro.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        MenuCadastro.setPreferredSize(new java.awt.Dimension(200, 32));

        MenuItemFornecedor.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MenuItemFornecedor.setForeground(new java.awt.Color(0, 0, 102));
        MenuItemFornecedor.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/fornecedor.png"))); // NOI18N
        MenuItemFornecedor.setMnemonic('F');
        MenuItemFornecedor.setText("Fornecedor");
        MenuItemFornecedor.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        MenuItemFornecedor.setPreferredSize(new java.awt.Dimension(200, 25));
        MenuCadastro.add(MenuItemFornecedor);
        MenuCadastro.add(jSeparator1);

        MenuCliente.setForeground(new java.awt.Color(0, 0, 102));
        MenuCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/cliente.png"))); // NOI18N
        MenuCliente.setMnemonic('I');
        MenuCliente.setText("Cliente");
        MenuCliente.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        MenuCliente.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MenuCliente.setPreferredSize(new java.awt.Dimension(200, 25));

        MenuItemPF.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MenuItemPF.setForeground(new java.awt.Color(0, 0, 102));
        MenuItemPF.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/pessoa fisica.png"))); // NOI18N
        MenuItemPF.setMnemonic('P');
        MenuItemPF.setText("Pessoa Física");
        MenuItemPF.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        MenuItemPF.setPreferredSize(new java.awt.Dimension(200, 25));
        MenuCliente.add(MenuItemPF);
        MenuCliente.add(jSeparator2);

        MenuItemPJ.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MenuItemPJ.setForeground(new java.awt.Color(0, 51, 102));
        MenuItemPJ.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/pessoa juridica.png"))); // NOI18N
        MenuItemPJ.setMnemonic('J');
        MenuItemPJ.setText("Pessoa Juridíca");
        MenuItemPJ.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        MenuItemPJ.setPreferredSize(new java.awt.Dimension(200, 25));
        MenuCliente.add(MenuItemPJ);

        MenuCadastro.add(MenuCliente);
        MenuCadastro.add(jSeparator3);

        MenuBD.setForeground(new java.awt.Color(0, 51, 102));
        MenuBD.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/banco de dados.png"))); // NOI18N
        MenuBD.setText("Banco de dados");
        MenuBD.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        MenuBD.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MenuBD.setPreferredSize(new java.awt.Dimension(200, 25));

        MenuItemConectar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MenuItemConectar.setForeground(new java.awt.Color(0, 51, 102));
        MenuItemConectar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/conectar.png"))); // NOI18N
        MenuItemConectar.setMnemonic('X');
        MenuItemConectar.setText("Conectar");
        MenuItemConectar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        MenuItemConectar.setPreferredSize(new java.awt.Dimension(200, 25));
        MenuBD.add(MenuItemConectar);
        MenuBD.add(jSeparator4);

        MenuItemDesconectar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MenuItemDesconectar.setForeground(new java.awt.Color(0, 51, 102));
        MenuItemDesconectar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/desconectar.png"))); // NOI18N
        MenuItemDesconectar.setMnemonic('D');
        MenuItemDesconectar.setText("Desconectar");
        MenuItemDesconectar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        MenuItemDesconectar.setPreferredSize(new java.awt.Dimension(200, 25));
        MenuBD.add(MenuItemDesconectar);

        MenuCadastro.add(MenuBD);
        MenuCadastro.add(jSeparator5);

        MenuItemProduto.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MenuItemProduto.setForeground(new java.awt.Color(0, 51, 102));
        MenuItemProduto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/produto.png"))); // NOI18N
        MenuItemProduto.setMnemonic('P');
        MenuItemProduto.setText("Produto");
        MenuItemProduto.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        MenuItemProduto.setPreferredSize(new java.awt.Dimension(200, 25));
        MenuCadastro.add(MenuItemProduto);
        MenuCadastro.add(jSeparator6);

        MenuItemExit.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        MenuItemExit.setForeground(new java.awt.Color(0, 51, 102));
        MenuItemExit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/exit.png"))); // NOI18N
        MenuItemExit.setMnemonic('S');
        MenuItemExit.setText("Sair do Sistema");
        MenuItemExit.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        MenuItemExit.setPreferredSize(new java.awt.Dimension(200, 25));
        MenuCadastro.add(MenuItemExit);

        MenuPrincipal.add(MenuCadastro);

        MenuVendas.setForeground(new java.awt.Color(0, 0, 102));
        MenuVendas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/vendas.png"))); // NOI18N
        MenuVendas.setMnemonic('V');
        MenuVendas.setText("Vendas");
        MenuVendas.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        MenuVendas.setPreferredSize(new java.awt.Dimension(200, 19));

        jMenuItem1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jMenuItem1.setForeground(new java.awt.Color(0, 0, 102));
        jMenuItem1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/pedido.png"))); // NOI18N
        jMenuItem1.setMnemonic('P');
        jMenuItem1.setText("Pedido");
        jMenuItem1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jMenuItem1.setPreferredSize(new java.awt.Dimension(200, 25));
        MenuVendas.add(jMenuItem1);

        MenuPrincipal.add(MenuVendas);

        MenuNotaFiscal.setForeground(new java.awt.Color(0, 0, 102));
        MenuNotaFiscal.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/nota fiscal.png"))); // NOI18N
        MenuNotaFiscal.setMnemonic('N');
        MenuNotaFiscal.setText("Nota Fiscal");
        MenuNotaFiscal.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        MenuNotaFiscal.setPreferredSize(new java.awt.Dimension(200, 32));

        jMenuItem2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jMenuItem2.setForeground(new java.awt.Color(0, 51, 102));
        jMenuItem2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/emitir.png"))); // NOI18N
        jMenuItem2.setMnemonic('T');
        jMenuItem2.setText("Emitir");
        jMenuItem2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jMenuItem2.setPreferredSize(new java.awt.Dimension(200, 25));
        MenuNotaFiscal.add(jMenuItem2);

        MenuPrincipal.add(MenuNotaFiscal);

        setJMenuBar(MenuPrincipal);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Principal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu MenuBD;
    private javax.swing.JMenu MenuCadastro;
    private javax.swing.JMenu MenuCliente;
    private javax.swing.JMenuItem MenuItemConectar;
    private javax.swing.JMenuItem MenuItemDesconectar;
    private javax.swing.JMenuItem MenuItemExit;
    private javax.swing.JMenuItem MenuItemFornecedor;
    private javax.swing.JMenuItem MenuItemPF;
    private javax.swing.JMenuItem MenuItemPJ;
    private javax.swing.JMenuItem MenuItemProduto;
    private javax.swing.JMenu MenuNotaFiscal;
    private javax.swing.JMenuBar MenuPrincipal;
    private javax.swing.JMenu MenuVendas;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private javax.swing.JPopupMenu.Separator jSeparator3;
    private javax.swing.JPopupMenu.Separator jSeparator4;
    private javax.swing.JPopupMenu.Separator jSeparator5;
    private javax.swing.JPopupMenu.Separator jSeparator6;
    private javax.swing.JLabel lblFiguraPrincipal;
    // End of variables declaration//GEN-END:variables
}
